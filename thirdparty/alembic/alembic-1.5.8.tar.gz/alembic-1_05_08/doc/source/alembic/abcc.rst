:mod:`alembic.AbcCollection`
============================

.. automodule:: alembic.AbcCollection
   :members:
   :undoc-members:
