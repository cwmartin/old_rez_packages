Nuke default
============

This profile corresponds to the default Nuke color configuration (currently generated from Nuke 6.1).

If you have made modifications to a nuke color configuration, and wish to re-export your own custom OCIO profile, please refer to the nuke_to_ocio utility script distributed with OpenColorIO.

The following color transforms are defined:

- linear
- sRGB
- rec709
- Cineon
- Gamma 1.8
- Gamma 2.2
- Panalog
- REDLog
- ViperLog
- REDSpace
