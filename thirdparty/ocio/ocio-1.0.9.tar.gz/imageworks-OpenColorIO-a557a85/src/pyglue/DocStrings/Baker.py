
class Baker:
    """
    Baker
    """
    def __init__(self):
        pass
    def isEditable(self):
        pass
    def createEditableCopy(self):
        pass
    def setConfig(self, config):
        pass
    def getConfig(self):
        pass
    def setFormat(self, formatName):
        pass
    def getFormat(self):
        pass
    def setType(self, type):
        pass
    def getType(self):
        pass
    def setMetadata(self, metadata):
        pass
    def getMetadata(self):
        pass
    def setInputSpace(self, inputSpace):
        pass
    def getInputSpace(self):
        pass
    def setShaperSpace(self, shaperSpace):
        pass
    def getShaperSpace(self):
        pass
    def setLooks(self, looks):
        pass
    def getLooks(self):
        pass
    def setTargetSpace(self, targetSpace):
        pass
    def getTargetSpace(self):
        pass
    def setShaperSize(self, shapersize):
        pass
    def getShaperSize(self):
        pass
    def setCubeSize(self, cubesize):
        pass
    def getCubeSize(self):
        pass
    def bake(self):
        pass
    def getNumFormats(self):
        pass
    def getFormatNameByIndex(self, index):
        pass
    def getFormatExtensionByIndex(self, index):
        pass
